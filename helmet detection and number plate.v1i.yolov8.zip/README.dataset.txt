# helmet detection and number plate > 2023-06-15 1:44am
https://universe.roboflow.com/school-tbkct/helmet-detection-and-number-plate

Provided by a Roboflow user
License: CC BY 4.0

