# Tripling Detection > 2023-06-01 1:46pm
https://universe.roboflow.com/traffic-signal-violation-detection/tripling-detection-q0goq

Provided by a Roboflow user
License: CC BY 4.0

